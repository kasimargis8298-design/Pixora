import React from 'react'
export default function App(){
  return (<div style={{maxWidth:600, margin:'0 auto'}}>
    <h1>InstaLite Web</h1>
    <p>Feed will appear here.</p>
  </div>)
}
