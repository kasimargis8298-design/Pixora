Bu arşiv, InstaLite starter projesidir. Backend: FastAPI, Mobil: Expo, Web: Vite/React.
