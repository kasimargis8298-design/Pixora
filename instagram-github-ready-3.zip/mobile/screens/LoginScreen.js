import React from 'react';
import { View, Text } from 'react-native';
export default function LoginScreen(){
  return (<View><Text>Login (implement)</Text></View>)
}
