import React, {useEffect, useState} from 'react';
import { View, Text, FlatList, Image } from 'react-native';

export default function FeedScreen(){
  const [posts, setPosts] = useState([]);
  useEffect(()=>{
    fetch('http://10.0.2.2:8000/api/posts/feed')
      .then(r=>r.json())
      .then(setPosts).catch(console.warn)
  },[])
  return (
    <View style={{flex:1}}>
      <FlatList data={posts} keyExtractor={p=>String(p.id)} renderItem={({item})=> (
        <View style={{padding:10}}>
          <Image source={{uri: `http://10.0.2.2:8000${item.image_path}`}} style={{height:300}} />
          <Text>{item.caption}</Text>
        </View>
      )} />
    </View>
  )
}
