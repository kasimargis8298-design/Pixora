from fastapi import FastAPI
from .routers import auth, users, posts
from fastapi.staticfiles import StaticFiles

app = FastAPI(title='InstaLite API')

app.include_router(auth.router, prefix='/api/auth', tags=['auth'])
app.include_router(users.router, prefix='/api/users', tags=['users'])
app.include_router(posts.router, prefix='/api/posts', tags=['posts'])

app.mount('/uploads', StaticFiles(directory='./uploads'), name='uploads')
