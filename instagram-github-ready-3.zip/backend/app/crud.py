from . import models
from sqlalchemy.orm import Session
from passlib.context import CryptContext
import jwt
import os
from datetime import datetime, timedelta

pwd_ctx = CryptContext(schemes=['bcrypt'], deprecated='auto')
SECRET_KEY = os.getenv('SECRET_KEY', 'devsecret')
ALGORITHM = 'HS256'
ACCESS_TOKEN_EXPIRE_MINUTES = 60 * 24

# User
def get_user_by_username(db: Session, username: str):
    return db.query(models.User).filter(models.User.username == username).first()

def create_user(db: Session, username: str, email: str, password: str):
    hashed = pwd_ctx.hash(password)
    user = models.User(username=username, email=email, hashed_password=hashed)
    db.add(user); db.commit(); db.refresh(user)
    return user

def authenticate_user(db: Session, username: str, password: str):
    user = get_user_by_username(db, username)
    if not user: return None
    if not pwd_ctx.verify(password, user.hashed_password):
        return None
    return user

# Token
def create_access_token(data: dict, expires_delta: timedelta = None):
    to_encode = data.copy()
    expire = datetime.utcnow() + (expires_delta or timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES))
    to_encode.update({'exp': expire})
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)

# Posts
def create_post(db: Session, user_id: int, image_path: str, caption: str = None):
    post = models.Post(user_id=user_id, image_path=image_path, caption=caption)
    db.add(post); db.commit(); db.refresh(post)
    return post

def get_recent_posts(db: Session, limit: int = 20):
    return db.query(models.Post).order_by(models.Post.created_at.desc()).limit(limit).all()
