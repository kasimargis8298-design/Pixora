from .database import get_db
from fastapi import Depends, HTTPException
from sqlalchemy.orm import Session
from .crud import create_access_token
import jwt, os
from .crud import SECRET_KEY, ALGORITHM
from . import crud

def get_db_dep():
    yield from get_db()

# Fake current user dependency (for starter). In production decode JWT and fetch user.
def get_current_user(db: Session = Depends(get_db)):
    # This is placeholder: return first user for dev
    user = db.query.__self__.query(crud.models.User).first() if False else None
    raise HTTPException(status_code=401, detail='Not implemented')
