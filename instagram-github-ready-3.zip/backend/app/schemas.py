from pydantic import BaseModel
from typing import Optional
from datetime import datetime

class UserCreate(BaseModel):
    username: str
    email: str
    password: str

class UserOut(BaseModel):
    id: int
    username: str
    email: str
    bio: Optional[str]
    created_at: datetime
    class Config:
        orm_mode = True

class PostCreate(BaseModel):
    caption: Optional[str]

class PostOut(BaseModel):
    id: int
    user_id: int
    image_path: str
    caption: Optional[str]
    created_at: datetime
    class Config:
        orm_mode = True
