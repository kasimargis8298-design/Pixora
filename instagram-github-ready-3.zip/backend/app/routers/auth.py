from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.orm import Session
from .. import crud
from ..database import get_db

router = APIRouter()

class RegisterIn(BaseModel):
    username: str
    email: str
    password: str

class LoginIn(BaseModel):
    username: str
    password: str

@router.post('/register')
def register(payload: RegisterIn, db: Session = Depends(get_db)):
    if crud.get_user_by_username(db, payload.username):
        raise HTTPException(status_code=400, detail='Username exists')
    user = crud.create_user(db, payload.username, payload.email, payload.password)
    return {'user': user}

@router.post('/login')
def login(payload: LoginIn, db: Session = Depends(get_db)):
    user = crud.authenticate_user(db, payload.username, payload.password)
    if not user:
        raise HTTPException(status_code=400, detail='Invalid credentials')
    token = crud.create_access_token({'sub': str(user.id)})
    return {'access_token': token, 'token_type': 'bearer'}
