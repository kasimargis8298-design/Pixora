from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from ..database import get_db
from .. import crud, schemas

router = APIRouter()

@router.get('/', response_model=list[schemas.UserOut])
def list_users(db: Session = Depends(get_db)):
    return db.query(crud.models.User).all()
