from fastapi import APIRouter, Depends, File, UploadFile, Form
from sqlalchemy.orm import Session
from ..database import get_db
from .. import crud
import os, time, shutil

router = APIRouter()
UPLOAD_DIR = './uploads'
os.makedirs(UPLOAD_DIR, exist_ok=True)

@router.post('/create')
async def create_post(caption: str = Form(None), file: UploadFile = File(...), db: Session = Depends(get_db)):
    filename = f"{int(time.time())}_{file.filename}"
    dest = os.path.join(UPLOAD_DIR, filename)
    with open(dest, 'wb') as buffer:
        shutil.copyfileobj(file.file, buffer)
    post = crud.create_post(db, user_id=1, image_path=f"/uploads/{filename}", caption=caption)
    return post

@router.get('/feed')
def feed(limit: int = 20, db: Session = Depends(get_db)):
    return crud.get_recent_posts(db, limit)
