
# 📸 InstaLite – Instagram Benzeri Uygulama (GitHub Sürümü)

Bu proje; FastAPI backend, React Native mobil uygulama ve React web frontend içeren tam bir Instagram benzeri uygulama başlangıç paketidir.

## 🚀 Kurulum

### Backend
```bash
cd backend
pip install -r requirements.txt
uvicorn app.main:app --reload
```

### Mobil (React Native – Expo)
```bash
cd mobile
npm install
npm start
```

### Web (Vite + React)
```bash
cd web
npm install
npm run dev
```

## 📂 Proje Yapısı
```
backend/
mobile/
web/
docker-compose.yml
README.md
.gitignore
```
